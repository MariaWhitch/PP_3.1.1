package com.springbootcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrud311ApplicationTests {

    @Test
    void contextLoads() {
    }

}
